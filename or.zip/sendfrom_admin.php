<?php
if(!empty($_REQUEST['lable']) && !empty($_REQUEST['toaddress']) && !empty($_REQUEST['amount'])){

	$coind = $coin->validateaddress($_REQUEST['toaddress']);
	if($coind['isvalid']==true){
		$fromAccount = $_REQUEST['lable'];
		$tobitcoinaddress = $_REQUEST['toaddress'];
		$amount = (float)$_REQUEST['amount'];
		$comment = (string)'Sent by '.$_REQUEST['lable'].' to '.$tobitcoinaddress.' amount '.$amount;
		$comment_to = (string)'Sent to '.$tobitcoinaddress.' by '.$_REQUEST['lable'];
		
				//<bitcoinaddress> <amount> [comment] [comment-to]
		$tx = $coin->sendtoaddress($tobitcoinaddress,$amount,$comment,$comment_to,'subtractfeefromamount');
		
		$fileput = date('Y-m-d H:i:s').' -> '.$tx;
		file_put_contents('send-result.txt', $fileput, FILE_APPEND);
		
		if (strpos($tx, 'error') !== false) {
			$error = json_decode($tx);
			$r['data']['status']='falied';
			$r['data']['txn']='';
			$r['data']['error']=$error->error->message;
		}else{
			$r['data']['status']='success';
			$r['data']['txn']=$tx;
		}
		
	} else{
		$r['data']['status']='failed';
		$r['data']['msg']='wrong credentials';
	}
}
?>