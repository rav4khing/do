<?php
if(!empty($_REQUEST['lable']) && !empty($_REQUEST['toaddress']) && !empty($_REQUEST['amount'])){
	$fromAccount = $_REQUEST['lable'];
	$tobitcoinaddress = $_REQUEST['toaddress'];
	$amount = (float)$_REQUEST['amount'];
	$comment = 'Sent by '.$_REQUEST['lable'].' to '.$tobitcoinaddress;
	
	$tx = $coin->sendfrom($fromAccount,$tobitcoinaddress,$amount,1,$comment);
	
	
	$r['data']['status']='success';
	$r['data']['txn']=$tx;
} else{
	$r['data']['status']='failed';
	$r['data']['msg']='wrong credentials';
}
?>